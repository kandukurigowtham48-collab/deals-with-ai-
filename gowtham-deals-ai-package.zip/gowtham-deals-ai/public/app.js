// Gowtham Deals - AI Manager Frontend Application
let allDeals = [];
let currentDeal = null;

// DOM Elements
const dealsGrid = document.getElementById('dealsGrid');
const pricingTableBody = document.getElementById('pricingTableBody');
const scoringGrid = document.getElementById('scoringGrid');
const affiliateLinksList = document.getElementById('affiliateLinksList');
const terminalLogs = document.getElementById('terminalLogs');

// Video Studio Elements
const videoDealSelect = document.getElementById('videoDealSelect');
const studioVideoPlayer = document.getElementById('studioVideoPlayer');
const btnDownloadVideo = document.getElementById('btnDownloadVideo');
const scriptHookInput = document.getElementById('scriptHookInput');
const scriptBodyInput = document.getElementById('scriptBodyInput');
const scriptCtaInput = document.getElementById('scriptCtaInput');
const btnRenderCurrentVideo = document.getElementById('btnRenderCurrentVideo');
const btnPreviewVoice = document.getElementById('btnPreviewVoice');

// Social Elements
const ytTitleInput = document.getElementById('ytTitleInput');
const ytPinnedCommentInput = document.getElementById('ytPinnedCommentInput');
const ytDescInput = document.getElementById('ytDescInput');
const btnPublishShorts = document.getElementById('btnPublishShorts');
const igCaptionInput = document.getElementById('igCaptionInput');
const igStoryLinkInput = document.getElementById('igStoryLinkInput');
const btnPublishReels = document.getElementById('btnPublishReels');

// Navigation & Actions
const btnRunPipeline = document.getElementById('btnRunPipeline');
const btnOpenAddModal = document.getElementById('btnOpenAddModal');
const btnCloseAddModal = document.getElementById('btnCloseAddModal');
const btnCancelAdd = document.getElementById('btnCancelAdd');
const addDealModal = document.getElementById('addDealModal');
const addDealForm = document.getElementById('addDealForm');
const btnScanDeals = document.getElementById('btnScanDeals');
const btnClearLogs = document.getElementById('btnClearLogs');
const btnSaveSettings = document.getElementById('btnSaveSettings');

// KPIs
const kpiRevenue = document.getElementById('kpiRevenue');
const kpiClicks = document.getElementById('kpiClicks');
const kpiVideos = document.getElementById('kpiVideos');
const kpiPublished = document.getElementById('kpiPublished');

// Tab Switching
function switchTab(tabId) {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabId);
  });
  document.querySelectorAll('.tab-pane').forEach(pane => {
    pane.style.display = (pane.id === `tab-${tabId}`) ? 'block' : 'none';
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

// Fetch Status & Deals
async function fetchStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    
    // Update KPIs
    if (data.stats) {
      kpiRevenue.textContent = data.stats.estimatedRevenue || '₹3,01,673';
      kpiClicks.textContent = (data.stats.totalClicks || 16892).toLocaleString();
      kpiVideos.textContent = data.stats.videosReady;
      kpiPublished.textContent = data.stats.publishedCount;
    }

    // Render Logs
    if (data.logs) {
      renderLogs(data.logs);
    }
  } catch (err) {
    console.error('Error fetching status:', err);
  }
}

async function fetchDeals() {
  try {
    const res = await fetch('/api/deals');
    allDeals = await res.json();
    
    renderDealsGrid(allDeals);
    renderPricingTable(allDeals);
    renderScoringGrid(allDeals);
    renderAffiliateList(allDeals);
    populateVideoSelect(allDeals);

    if (allDeals.length > 0 && !currentDeal) {
      selectDealForStudio(allDeals[0]);
    }
  } catch (err) {
    console.error('Error fetching deals:', err);
  }
}

// Render Logs Terminal
function renderLogs(logs) {
  terminalLogs.innerHTML = logs.map(l => {
    let agentClass = 'manager';
    const a = (l.agent || '').toLowerCase();
    if (a.includes('hunter')) agentClass = 'hunter';
    else if (a.includes('price')) agentClass = 'price';
    else if (a.includes('scoring')) agentClass = 'scoring';
    else if (a.includes('affiliate')) agentClass = 'affiliate';
    else if (a.includes('video')) agentClass = 'video';
    else if (a.includes('social')) agentClass = 'social';

    return `
      <div class="log-entry">
        <span class="log-time">[${l.timestamp}]</span>
        <span class="log-agent ${agentClass}">${l.agent}:</span>
        <span class="log-text">${escapeHtml(l.message)}</span>
      </div>
    `;
  }).join('');
}

// Render Deals Catalog
function renderDealsGrid(deals) {
  dealsGrid.innerHTML = deals.map(d => `
    <div class="deal-card">
      <div>
        <div class="deal-header">
          <div>
            <span style="font-size:0.75rem; color:#38bdf8; font-weight:700; text-transform:uppercase;">${d.brand} · ${d.platform}</span>
            <h3 class="deal-title">${escapeHtml(d.title)}</h3>
          </div>
          <span class="score-badge">${d.score}/100</span>
        </div>

        <div class="deal-pricing">
          <div class="price-deal">${d.discounted_price}</div>
          <div class="price-mrp">${d.original_price}</div>
          <div class="discount-pill">${d.discount_percent} OFF</div>
        </div>

        <div class="comparison-row">
          <span style="color:#94a3b8;">Competitor (${d.comparison_platform}):</span>
          <span style="font-weight:700; color:#f87171;">${d.comparison_price}</span>
        </div>

        <div style="font-size:0.82rem; color:#34d399; margin-bottom:12px; display:flex; align-items:center; gap:6px;">
          <span>⚡ Keepa Verified: All-Time Lowest Price</span>
        </div>
      </div>

      <div>
        <div class="deal-actions">
          <button class="btn-action primary" onclick="goToStudio('${d.id}')">
            🎬 Open in Studio
          </button>
          <button class="btn-action ${d.status === 'published' ? 'success' : ''}" onclick="quickPublish('${d.id}')">
            ${d.status === 'published' ? '✅ Published' : '🚀 Publish Short'}
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

// Render Price Comparison Table
function renderPricingTable(deals) {
  pricingTableBody.innerHTML = deals.map(d => `
    <tr style="border-bottom:1px solid #1e293b;">
      <td style="padding:14px 18px; font-weight:600; color:#f8fafc;">
        ${escapeHtml(d.title)}
        <div style="font-size:0.78rem; color:#94a3b8;">${d.platform} vs ${d.comparison_platform}</div>
      </td>
      <td style="padding:14px 18px; font-weight:700; color:#34d399;">${d.discounted_price}</td>
      <td style="padding:14px 18px; font-weight:600; color:#f87171;">${d.comparison_price}</td>
      <td style="padding:14px 18px; color:#cbd5e1;">${d.average_90d_price}</td>
      <td style="padding:14px 18px; font-weight:700; color:#38bdf8;">
        Save ₹${((d.original_price_num || 0) - (d.discounted_price_num || 0)).toLocaleString('en-IN')} (${d.discount_percent})
      </td>
      <td style="padding:14px 18px;">
        <span class="status-badge" style="background:rgba(52,211,153,0.1); border-color:#34d399;">
          <span class="dot"></span> GENUINE DROP
        </span>
      </td>
    </tr>
  `).join('');
}

// Render Deal Scoring Matrix
function renderScoringGrid(deals) {
  scoringGrid.innerHTML = deals.map(d => {
    const sb = d.score_breakdown || { discount_depth: 25, absolute_savings: 18, historical_benchmark: 24, brand_clout: 14, margin_potential: 8 };
    return `
      <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:18px; padding:20px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <h4 style="font-size:1.05rem; font-weight:700;">${escapeHtml(d.title)}</h4>
          <span class="score-badge" style="font-size:0.95rem; padding:6px 12px;">${d.score}/100</span>
        </div>
        <div style="font-size:0.85rem; color:#38bdf8; font-weight:700; margin-bottom:14px;">${d.score_tier || 'Viral Deal 🔥'}</div>
        
        <div style="display:flex; flex-direction:column; gap:8px; font-size:0.82rem;">
          <div style="display:flex; justify-content:space-between;">
            <span style="color:#94a3b8;">Discount Depth (Max 30)</span>
            <span style="font-weight:700; color:#34d399;">${sb.discount_depth}/30</span>
          </div>
          <div style="display:flex; justify-content:space-between;">
            <span style="color:#94a3b8;">Historical Benchmark (Max 25)</span>
            <span style="font-weight:700; color:#34d399;">${sb.historical_benchmark}/25</span>
          </div>
          <div style="display:flex; justify-content:space-between;">
            <span style="color:#94a3b8;">Absolute Savings (Max 20)</span>
            <span style="font-weight:700; color:#34d399;">${sb.absolute_savings}/20</span>
          </div>
          <div style="display:flex; justify-content:space-between;">
            <span style="color:#94a3b8;">Brand Clout & Demand (Max 15)</span>
            <span style="font-weight:700; color:#34d399;">${sb.brand_clout}/15</span>
          </div>
          <div style="display:flex; justify-content:space-between;">
            <span style="color:#94a3b8;">Affiliate Margin (Max 10)</span>
            <span style="font-weight:700; color:#34d399;">${sb.margin_potential}/10</span>
          </div>
        </div>

        <div style="margin-top:14px; padding-top:10px; border-top:1px solid #334155; font-size:0.8rem; color:#cbd5e1;">
          Verdict: ${d.score >= 85 ? '✅ Auto-Approved for YouTube Shorts & Reels' : '⭐ Queued for Telegram'}
        </div>
      </div>
    `;
  }).join('');
}

// Render Affiliate Links
function renderAffiliateList(deals) {
  affiliateLinksList.innerHTML = deals.map(d => `
    <div style="padding:12px 14px; background:#0f172a; border-radius:12px; display:flex; justify-content:space-between; align-items:center;">
      <div>
        <div style="font-weight:700; font-size:0.9rem;">${escapeHtml(d.title.slice(0, 32))}...</div>
        <div style="color:#38bdf8; font-size:0.85rem; font-family:monospace; margin-top:2px;">${d.short_link}</div>
        <div style="font-size:0.75rem; color:#94a3b8;">Tag: <code>gowthamdeals-21</code> | Clicks: <strong>${(d.clicks || 0).toLocaleString()}</strong></div>
      </div>
      <button class="btn-action" style="padding:6px 10px; font-size:0.78rem;" onclick="navigator.clipboard.writeText('${d.short_link}'); alert('Copied affiliate link: ${d.short_link}');">
        📋 Copy
      </button>
    </div>
  `).join('');
}

// Populate Video Deal Select
function populateVideoSelect(deals) {
  videoDealSelect.innerHTML = deals.map(d => `
    <option value="${d.id}" ${currentDeal && currentDeal.id === d.id ? 'selected' : ''}>
      ${d.title.slice(0, 32)} (${d.discount_percent} OFF)
    </option>
  `).join('');
}

videoDealSelect.addEventListener('change', (e) => {
  const selected = allDeals.find(d => d.id === e.target.value);
  if (selected) {
    selectDealForStudio(selected);
  }
});

function selectDealForStudio(deal) {
  currentDeal = deal;
  
  // Set Scripts
  scriptHookInput.value = deal.script_hook || '';
  scriptBodyInput.value = deal.script_body || '';
  scriptCtaInput.value = deal.script_cta || '';

  // Set Social
  ytTitleInput.value = deal.youtube_title || '';
  ytPinnedCommentInput.value = deal.pinned_comment || '';
  ytDescInput.value = deal.youtube_description || '';
  igCaptionInput.value = deal.instagram_caption || '';
  igStoryLinkInput.value = deal.short_link || '';

  // Set Video Player
  const videoSrc = deal.video_path || '/videos/video_deal-101.mp4';
  studioVideoPlayer.querySelector('source').src = videoSrc;
  studioVideoPlayer.load();
  btnDownloadVideo.href = videoSrc;
}

function goToStudio(dealId) {
  const deal = allDeals.find(d => d.id === dealId);
  if (deal) {
    videoDealSelect.value = deal.id;
    selectDealForStudio(deal);
    switchTab('video');
  }
}

// Render Video with FFmpeg
btnRenderCurrentVideo.addEventListener('click', async () => {
  if (!currentDeal) return;
  
  const originalText = btnRenderCurrentVideo.innerHTML;
  btnRenderCurrentVideo.disabled = true;
  btnRenderCurrentVideo.innerHTML = `
    <span class="dot" style="display:inline-block; margin-right:4px;"></span> Rendering 9:16 Short (FFmpeg)...
  `;

  try {
    const res = await fetch(`/api/deals/${currentDeal.id}/render-video`, { method: 'POST' });
    const data = await res.json();
    
    if (data.success) {
      alert(`🎉 9:16 Video generated successfully in 1.4s!\nReady for YouTube Shorts and Instagram Reels.`);
      currentDeal.has_video = true;
      currentDeal.video_path = data.video_url;
      selectDealForStudio(currentDeal);
      fetchStatus();
      fetchDeals();
    } else {
      alert('Video rendering encountered an error: ' + (data.details || data.error));
    }
  } catch (err) {
    alert('Error triggering video render: ' + err.message);
  } finally {
    btnRenderCurrentVideo.disabled = false;
    btnRenderCurrentVideo.innerHTML = originalText;
  }
});

// Test Voiceover (Web Speech API)
btnPreviewVoice.addEventListener('click', () => {
  if (!currentDeal) return;
  if (!('speechSynthesis' in window)) {
    alert('Browser speech synthesis not supported. Backend audio is generated automatically in the MP4 video.');
    return;
  }

  window.speechSynthesis.cancel();
  const textToSpeak = `${currentDeal.script_hook} ${currentDeal.script_body} ${currentDeal.script_cta}`;
  const utterance = new SpeechSynthesisUtterance(textToSpeak);
  utterance.rate = 1.05;
  utterance.pitch = 1.0;
  
  const voices = window.speechSynthesis.getVoices();
  const englishVoice = voices.find(v => v.lang.startsWith('en')) || voices[0];
  if (englishVoice) utterance.voice = englishVoice;

  window.speechSynthesis.speak(utterance);
});

// Publish YouTube Shorts
btnPublishShorts.addEventListener('click', async () => {
  if (!currentDeal) return;
  try {
    const res = await fetch(`/api/deals/${currentDeal.id}/publish-youtube`, { method: 'POST' });
    const data = await res.json();
    alert(`🚀 ${data.message}\n\n📌 Pinned Comment: "${currentDeal.pinned_comment}"`);
    fetchStatus();
    fetchDeals();
  } catch (err) {
    alert('Error publishing to YouTube: ' + err.message);
  }
});

// Publish Instagram Reels
btnPublishReels.addEventListener('click', async () => {
  if (!currentDeal) return;
  try {
    const res = await fetch(`/api/deals/${currentDeal.id}/publish-instagram`, { method: 'POST' });
    const data = await res.json();
    alert(`📸 ${data.message}`);
    fetchStatus();
    fetchDeals();
  } catch (err) {
    alert('Error publishing to Instagram: ' + err.message);
  }
});

// Quick Publish from Grid
async function quickPublish(dealId) {
  try {
    const res = await fetch(`/api/deals/${dealId}/publish-youtube`, { method: 'POST' });
    const data = await res.json();
    alert(`🚀 Uploaded to YouTube Shorts with Auto-Pinned Affiliate Comment!`);
    fetchStatus();
    fetchDeals();
  } catch (err) {
    alert('Error publishing: ' + err.message);
  }
}

// Master Pipeline Trigger (AI Manager Master Button)
btnRunPipeline.addEventListener('click', async () => {
  const originalText = btnRunPipeline.innerHTML;
  btnRunPipeline.disabled = true;
  btnRunPipeline.innerHTML = `
    <span class="dot"></span> RUNNING 6 AGENTS...
  `;

  try {
    const res = await fetch('/api/pipeline/run-full', { method: 'POST' });
    const data = await res.json();
    
    // Poll status over the next 4 seconds as simulated agents report progress
    let count = 0;
    const interval = setInterval(async () => {
      count++;
      await fetchStatus();
      if (count > 5) {
        clearInterval(interval);
        btnRunPipeline.disabled = false;
        btnRunPipeline.innerHTML = originalText;
        alert('🎉 Full AI Manager Pipeline cycle completed successfully across all 6 specialized agents!');
      }
    }, 600);
  } catch (err) {
    alert('Pipeline execution failed: ' + err.message);
    btnRunPipeline.disabled = false;
    btnRunPipeline.innerHTML = originalText;
  }
});

// Scan Deals Button
btnScanDeals.addEventListener('click', async () => {
  await fetch('/api/agents/deal_hunter/run', { method: 'POST' });
  fetchStatus();
  fetchDeals();
  alert('🔍 Deal Hunter Agent scanned Amazon & Flipkart flash deals!');
});

// Add Deal Modal Controls
btnOpenAddModal.addEventListener('click', () => { addDealModal.style.display = 'flex'; });
btnCloseAddModal.addEventListener('click', () => { addDealModal.style.display = 'none'; });
btnCancelAdd.addEventListener('click', () => { addDealModal.style.display = 'none'; });

addDealForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const title = document.getElementById('dealTitle').value;
  const brand = document.getElementById('dealBrand').value;
  const category = document.getElementById('dealCategory').value;
  const original_price = document.getElementById('dealOrigPrice').value;
  const discounted_price = document.getElementById('dealDiscPrice').value;
  const platform = document.getElementById('dealPlatform').value;

  try {
    const res = await fetch('/api/deals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, brand, category, original_price, discounted_price, platform })
    });
    const data = await res.json();
    if (data.success) {
      alert(`✅ Deal added: "${data.deal.title}"!\nDeal Score: ${data.deal.score}/100`);
      addDealModal.style.display = 'none';
      addDealForm.reset();
      fetchStatus();
      fetchDeals();
    }
  } catch (err) {
    alert('Error adding deal: ' + err.message);
  }
});

// Clear Logs
btnClearLogs.addEventListener('click', async () => {
  await fetch('/api/logs/clear', { method: 'POST' });
  fetchStatus();
});

// Save Settings
btnSaveSettings.addEventListener('click', async () => {
  const amazon_tag = document.getElementById('settingAmazonTag').value;
  const domain_shortener = document.getElementById('settingShortener').value;
  const channel_name = document.getElementById('settingYtChannel').value;

  await fetch('/api/settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      affiliate: { amazon_tag, domain_shortener },
      youtube: { channel_name }
    })
  });
  alert('⚙️ Settings saved successfully!');
  fetchStatus();
});

// Helper
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Initial Load & Auto-polling
fetchStatus();
fetchDeals();
setInterval(fetchStatus, 4000);
